﻿namespace Sideas.Hygge
{
    public abstract class HyggeApplicationTestBase : HyggeTestBase<HyggeApplicationTestModule> 
    {

    }
}
