﻿namespace Sideas.Hygge
{
    public abstract class HyggeDomainTestBase : HyggeTestBase<HyggeDomainTestModule> 
    {

    }
}
