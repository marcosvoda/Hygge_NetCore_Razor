﻿using Volo.Abp;

namespace Sideas.Hygge.EntityFrameworkCore
{
    public abstract class HyggeEntityFrameworkCoreTestBase : HyggeTestBase<HyggeEntityFrameworkCoreTestModule> 
    {

    }
}
