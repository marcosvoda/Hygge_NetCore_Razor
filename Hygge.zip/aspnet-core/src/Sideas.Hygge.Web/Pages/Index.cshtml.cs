﻿namespace Sideas.Hygge.Web.Pages
{
    public class IndexModel : HyggePageModel
    {
        public void OnGet()
        {
            
        }
    }
}