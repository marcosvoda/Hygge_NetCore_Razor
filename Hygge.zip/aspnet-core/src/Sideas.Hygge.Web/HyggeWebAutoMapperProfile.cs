﻿using AutoMapper;

namespace Sideas.Hygge.Web
{
    public class HyggeWebAutoMapperProfile : Profile
    {
        public HyggeWebAutoMapperProfile()
        {
            //Define your AutoMapper configuration here for the Web project.
        }
    }
}
