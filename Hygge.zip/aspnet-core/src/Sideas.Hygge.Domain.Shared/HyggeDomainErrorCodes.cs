﻿namespace Sideas.Hygge
{
    public static class HyggeDomainErrorCodes
    {
        /* You can add your business exception error codes here, as constants */
    }
}
