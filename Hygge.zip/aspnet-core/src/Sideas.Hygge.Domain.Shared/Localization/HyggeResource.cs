﻿using Volo.Abp.Localization;

namespace Sideas.Hygge.Localization
{
    [LocalizationResourceName("Hygge")]
    public class HyggeResource
    {

    }
}