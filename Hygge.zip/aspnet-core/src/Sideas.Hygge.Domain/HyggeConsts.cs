﻿namespace Sideas.Hygge
{
    public static class HyggeConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;
    }
}
