﻿namespace Sideas.Hygge.Settings
{
    public static class HyggeSettings
    {
        private const string Prefix = "Hygge";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}