﻿namespace Sideas.Hygge.Permissions
{
    public static class HyggePermissions
    {
        public const string GroupName = "Hygge";

        //Add your own permission names. Example:
        //public const string MyPermission1 = GroupName + ".MyPermission1";
    }
}