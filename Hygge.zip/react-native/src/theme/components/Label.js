// @flow

export default () => {
  const labelTheme = {
    '.focused': {
      width: 0,
    },
    '.textPrimary': {
      color: 'gray',
    },
    fontSize: 17,
  };

  return labelTheme;
};
